
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

import { OptionMenuService } from './observable/option-menu/option-menu.service';
import { ProfileCard } from './profile-card/profile-card';

import { KeycloakService } from 'keycloak-angular';

@Component({
    selector: 'app-root',
    standalone: true,
    imports: [
        CommonModule,
        RouterOutlet,
        RouterModule,
        ButtonModule,
        ToastModule,
        ConfirmDialogModule,
        ProfileCard
    ],
    templateUrl: './app.html',
    styleUrls: ['./app.css']
})
export class App implements OnInit {

    private optionMenuService = inject(OptionMenuService);
    private router = inject(Router);
    private http = inject(HttpClient);
    private keycloak = inject(KeycloakService);

    isLoggedIn = false;
    isLoading = true;

    session: any = null;
    notifCount = 0;

    private activeId = '';

    private readonly baseOptions: any[] = [
        {
            id: '',
            route: '/',
            icon: 'home',
            text: 'Inicio',
            active: false
        },
        {
            id: 'suggestioninsert',
            route: '/suggestion/insert',
            icon: 'bookmark',
            text: 'Sugerencias',
            active: false
        },
        {
            id: 'complaintinsert',
            route: '/complaint/insert',
            icon: 'shield',
            text: 'Quejas',
            active: false
        },
        {
            id: 'followup',
            route: '/follow-up/view',
            icon: 'book',
            text: 'Seguimiento',
            active: false
        }
    ];

    menuOptions: any[] = this.baseOptions.map(o => ({ ...o }));

    get isManager(): boolean {
        if (!this.isLoggedIn) {
            return false;
        }

        const roles = this.keycloak.getUserRoles();

        return roles.some(r => {
            const role = r.toUpperCase();

            return role.includes('ADMIN') ||
                   role.includes('ENCARGADO');
        });
    }

    async ngOnInit(): Promise<void> {

        try {
            // Cargar sesión antes de mostrar la interfaz
            await this.loadInitialSession();

            // Escuchar cambios del menú
            this.optionMenuService.data$().subscribe({
                next: (response: any) => {

                    this.activeId = response;

                    this.menuOptions = this.menuOptions.map(o => ({
                        ...o,
                        active: o.id === response
                    }));
                }
            });

        } catch (error) {
            console.error('Error al inicializar la aplicación:', error);
        } finally {
            this.isLoading = false;
        }
    }

    private async loadInitialSession(): Promise<void> {

        this.isLoggedIn = await this.keycloak.isLoggedIn();

        if (this.isLoggedIn) {

            try {

                const profile: any = await this.keycloak.loadUserProfile();
                const roles = this.keycloak.getUserRoles();

                const manager = roles.some(r => {
                    const role = r.toUpperCase();

                    return role.includes('ADMIN') ||
                           role.includes('ENCARGADO');
                });

                this.session = {
                    username: profile.username,
                    email: profile.email,
                    firstName: profile.firstName ?? profile.username,
                    lastName: profile.lastName ?? '',
                    role: manager ? 'Encargado' : 'Usuario',
                    roles: roles
                };

            } catch (error) {
                console.error('Error al cargar perfil:', error);
                this.session = null;
                this.isLoggedIn = false;
            }

        } else {
            this.session = null;
        }

        // Construir menú una sola vez
        const options = this.baseOptions.map(o => ({ ...o }));

        if (this.isManager) {
            options.push({
                id: 'admin',
                route: '/admin',
                icon: 'chart-bar',
                text: 'Panel',
                active: false
            });
        }

        this.menuOptions = options.map(o => ({
            ...o,
            active: o.id === this.activeId
        }));

        // Redirigir únicamente si corresponde
        const currentPath = this.router.url;

        if (this.isManager && !currentPath.startsWith('/admin')) {
            await this.router.navigateByUrl('/admin');
        }

        // Cargar notificaciones después de tener la sesión
        this.loadNotifications();
    }

    private async loadNotifications(): Promise<void> {

        if (!this.isManager) {
            this.notifCount = 0;
            return;
        }

        const pending = (data: any): number => {

            try {
                const list = typeof data === 'string'
                    ? JSON.parse(data)
                    : data;

                return Array.isArray(list)
                    ? list.filter(
                        (i: any) =>
                            i?.status === 'Pendiente de revisión'
                    ).length
                    : 0;

            } catch {
                return 0;
            }
        };

        const complaint$ = this.http.get(
            'http://localhost:8080/complaint/getall',
            { responseType: 'text' }
        ).pipe(
            catchError(() => of('[]'))
        );

        const suggestion$ = this.http.get(
            'http://localhost:8080/suggestion/getall',
            { responseType: 'text' }
        ).pipe(
            catchError(() => of('[]'))
        );

        try {

            const [complaints, suggestions] = await Promise.all([
                firstValueFrom(complaint$),
                firstValueFrom(suggestion$)
            ]);

            this.notifCount =
                pending(complaints) + pending(suggestions);

        } catch (error) {
            console.error('Error al cargar notificaciones:', error);
            this.notifCount = 0;
        }
    }

    login(): void {
        this.keycloak.login({
            redirectUri: window.location.origin
        });
    }

    goLogin(): void {
        this.login();
    }

    goNotifications(): void {
        if (this.isManager) {
            this.router.navigate(['/admin']);
        }
    }

    logout(): void {

        this.notifCount = 0;
        this.session = null;
        this.isLoggedIn = false;

        this.keycloak.logout(window.location.origin);
    }
}
