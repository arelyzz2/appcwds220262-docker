import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-M5MWSKUN.js";
import "./chunk-NSOVQP73.js";
import "./chunk-HKHAFIDD.js";
import "./chunk-2SZK2VJJ.js";
import "./chunk-DP2MNWDH.js";
import "./chunk-HWXVP55U.js";
import "./chunk-7YB6YR3W.js";
import "./chunk-HWYXSU2G.js";
import "./chunk-JRFR6BLO.js";
import "./chunk-MARUHEWW.js";
import "./chunk-GOMI4DH3.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
